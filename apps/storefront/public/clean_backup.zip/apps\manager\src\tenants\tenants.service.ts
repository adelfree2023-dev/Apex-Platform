import { Injectable, Logger, NotFoundException, ConflictException, InternalServerErrorException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { VendureService } from '../vendure/vendure.service';
import { CreateTenantDto, UpdateTenantDto } from './dto/tenant.dto';
import { Tenant, TenantStatus } from '@prisma/client';

@Injectable()
export class TenantsService {
    private readonly logger = new Logger(TenantsService.name);

    constructor(
        private readonly prisma: PrismaService,
        private readonly vendureService: VendureService,
    ) { }

    /**
     * Create a new tenant with Vendure channel integration
     * This is the CORE integration point
     */
    async create(dto: CreateTenantDto): Promise<{ tenant: Tenant; channel: any }> {
        // Generate slug from name if not provided
        const slug = dto.slug || this.generateSlug(dto.name);

        // Check if slug already exists
        const existing = await this.prisma.tenant.findUnique({ where: { slug } });
        if (existing) {
            throw new ConflictException(`Tenant with slug "${slug}" already exists`);
        }

        this.logger.log(`📦 Creating tenant: ${dto.name} (${slug})`);

        // Step 1: Create tenant in database (without Vendure info)
        let tenant = await this.prisma.tenant.create({
            data: {
                name: dto.name,
                slug,
                domain: dto.domain,
                type: dto.type || 'RETAIL',
                status: TenantStatus.TRIAL,
            },
        });

        this.logger.log(`✅ Tenant created in DB: ${tenant.id}`);

        // Step 2: Create Channel in Vendure
        try {
            const channel = await this.vendureService.createChannel(slug, dto.name);

            // Step 3: Update tenant with Vendure channel info
            tenant = await this.prisma.tenant.update({
                where: { id: tenant.id },
                data: {
                    vendureChannelId: channel.id,
                    vendureChannelToken: channel.token,
                },
            });

            this.logger.log(`🎉 INTEGRATION SUCCESS!`);
            this.logger.log(`   Tenant ID: ${tenant.id}`);
            this.logger.log(`   Channel ID: ${channel.id}`);

            return { tenant, channel };
        } catch (error) {
            // Rollback: delete tenant if Vendure fails
            this.logger.error('❌ Vendure integration failed, rolling back tenant creation');
            await this.prisma.tenant.delete({ where: { id: tenant.id } });
            throw new InternalServerErrorException(
                'Failed to create Vendure channel. Tenant creation rolled back.',
            );
        }
    }

    /**
     * Get all tenants
     */
    async findAll(): Promise<Tenant[]> {
        return this.prisma.tenant.findMany({
            orderBy: { createdAt: 'desc' },
        });
    }

    /**
     * Get tenant by ID
     */
    async findById(id: string): Promise<Tenant> {
        const tenant = await this.prisma.tenant.findUnique({ where: { id } });
        if (!tenant) {
            throw new NotFoundException(`Tenant with ID "${id}" not found`);
        }
        return tenant;
    }

    /**
     * Get tenant by slug
     */
    async findBySlug(slug: string): Promise<Tenant> {
        const tenant = await this.prisma.tenant.findUnique({ where: { slug } });
        if (!tenant) {
            throw new NotFoundException(`Tenant with slug "${slug}" not found`);
        }
        return tenant;
    }

    /**
     * Update tenant
     */
    async update(id: string, dto: UpdateTenantDto): Promise<Tenant> {
        const tenant = await this.findById(id);

        return this.prisma.tenant.update({
            where: { id: tenant.id },
            data: dto,
        });
    }

    /**
     * Soft delete (suspend) tenant
     */
    async suspend(id: string): Promise<Tenant> {
        const tenant = await this.findById(id);

        return this.prisma.tenant.update({
            where: { id: tenant.id },
            data: { status: TenantStatus.SUSPENDED },
        });
    }

    /**
     * Reactivate tenant
     */
    async reactivate(id: string): Promise<Tenant> {
        const tenant = await this.findById(id);

        return this.prisma.tenant.update({
            where: { id: tenant.id },
            data: { status: TenantStatus.ACTIVE },
        });
    }

    /**
     * Hard delete tenant (use with caution!)
     */
    async delete(id: string): Promise<void> {
        const tenant = await this.findById(id);

        // Delete Vendure channel if exists
        if (tenant.vendureChannelId) {
            await this.vendureService.deleteChannel(tenant.vendureChannelId);
        }

        // Delete tenant from database
        await this.prisma.tenant.delete({ where: { id: tenant.id } });

        this.logger.log(`🗑️ Tenant deleted: ${tenant.slug}`);
    }

    /**
     * Seed realistic products for a tenant
     */
    async seedProducts(slug: string): Promise<any> {
        const tenant = await this.findBySlug(slug);
        if (!tenant.vendureChannelToken) {
            throw new NotFoundException('Tenant has no Vendure channel');
        }

        this.logger.log(`🌱 Seeding REALISTIC products for tenant: ${tenant.slug}`);

        const realProducts = [
            { name: "iPhone 15 Pro Max", price: 119900, description: "Titanium design, A17 Pro chip, 48MP Main camera." },
            { name: "MacBook Air 15-inch", price: 129900, description: "Supercharged by M2. Impressively big. Impossibly thin." },
            { name: "Sony WH-1000XM5", price: 34800, description: "Industry-leading noise canceling headphones with Auto NC Optimizer." },
            { name: "Samsung Galaxy S24 Ultra", price: 129900, description: "Galaxy AI is here. Epic titanium design." },
            { name: "PlayStation 5 Console", price: 49900, description: "Experience lightning fast loading with an ultra-high speed SSD." },
            { name: "Nike Air Jordan 1", price: 18000, description: "Iconic style, everyday comfort. Premium leather upper." },
            { name: "Adidas Ultraboost Light", price: 19000, description: "Lightest Ultraboost ever with 30% lighter BOOST material." },
            { name: "Ray-Ban Aviator Classic", price: 16000, description: "Originally designed for U.S. Aviators in 1937." },
            { name: "Herman Miller Aeron Chair", price: 120000, description: "The benchmark for ergonomic seating." },
            { name: "Dyson V15 Detect", price: 74900, description: "Laser reveals microscopic dust. Powerful smart cleaning." },
        ];

        const results = [];

        // Loop to create 30 products (repeating the list if needed)
        for (let i = 0; i < 30; i++) {
            const product = realProducts[i % realProducts.length];
            // If repeating, append (Copy X) to avoid duplicate slugs in some systems, though Vendure handles slug dedup
            const uniqueName = i >= realProducts.length ? `${product.name} (Copy ${Math.floor(i / realProducts.length)})` : product.name;

            const productMutation = `
                mutation CreateProduct($input: CreateProductInput!) {
                    createProduct(input: $input) {
                        id
                        name
                        variants { id }
                    }
                }
            `;

            const productInput = {
                input: {
                    translations: [{
                        languageCode: 'en',
                        name: uniqueName,
                        slug: uniqueName.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Math.floor(Math.random() * 1000),
                        description: product.description,
                    }],
                }
            };

            try {
                const pData = await this.vendureService.executeGraphQL(productMutation, productInput, tenant.vendureChannelToken);
                const variantId = pData.createProduct.variants[0].id;

                const priceMutation = `
                    mutation UpdateVariant($input: [UpdateProductVariantInput!]!) {
                        updateProductVariants(input: $input) {
                            id
                            price
                        }
                    }
                `;

                await this.vendureService.executeGraphQL(priceMutation, {
                    input: [{
                        id: variantId,
                        price: product.price,
                        sku: `SKU-${tenant.slug}-${i}`
                    }]
                }, tenant.vendureChannelToken);

                results.push({ name: uniqueName, status: 'Created' });

            } catch (e) {
                this.logger.error(`Failed to seed product ${uniqueName}`, e);
            }
        }

        return { success: true, seeded: results };
    }

    /**
     * Generate URL-friendly slug from name
     */
    private generateSlug(name: string): string {
        return name
            .toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '') // Remove special chars
            .replace(/\s+/g, '-') // Replace spaces with hyphens
            .replace(/-+/g, '-'); // Remove consecutive hyphens
    }
}
