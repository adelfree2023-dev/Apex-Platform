/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['localhost', '34.18.154.179'], // Allow Vendure and local images
        remotePatterns: [
            {
                protocol: 'http',
                hostname: 'localhost',
                port: '3001',
                pathname: '/assets/**',
            },
            {
                protocol: 'https',
                hostname: '**',
            }
        ],
    },
};

module.exports = nextConfig;
