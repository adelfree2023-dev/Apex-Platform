import { notFound } from "next/navigation";
import Link from "next/link";
import { getTenantBySlug } from "@/lib/manager-client";
import { createVendureClient, vendureApi } from "@/lib/vendure-client";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Product } from "@/types/product";

export default async function TenantPage({
    params,
}: {
    params: Promise<{ tenant: string }>;
}) {
    const { tenant } = await params;

    // 1. Get Tenant for Token
    const tenantData = await getTenantBySlug(tenant);
    if (!tenantData || !tenantData.vendureChannelToken) {
        notFound();
    }

    // 2. Init Vendure Client
    const client = createVendureClient(tenantData.vendureChannelToken);

    // 3. Fetch Products
    const products = await vendureApi.getProducts(client);

    return (
        <div className="container mx-auto">
            <div className="flex items-center justify-between mb-8">
                <h1 className="text-3xl font-bold">Featured Products</h1>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {products.length === 0 ? (
                    <div className="col-span-full text-center py-12 text-gray-500">
                        No products found.
                    </div>
                ) : (
                    products.map((product) => {
                        // Safe access to first variant price
                        const price = product.variants[0]?.price || 0;

                        return (
                            <Card key={product.id} className="overflow-hidden flex flex-col hover:shadow-lg transition-shadow">
                                <div className="aspect-square relative bg-white border-b">
                                    {product.featuredAsset ? (
                                        <img
                                            src={product.featuredAsset.preview}
                                            alt={product.name}
                                            className="object-cover w-full h-full"
                                        />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center bg-gray-100 text-gray-400">
                                            No Image
                                        </div>
                                    )}
                                </div>

                                <CardHeader className="p-4 pb-0">
                                    <CardTitle className="line-clamp-1 text-lg">{product.name}</CardTitle>
                                </CardHeader>

                                <CardContent className="p-4 pt-2 flex-1">
                                    <p className="font-bold text-lg text-primary">
                                        {(price / 100).toLocaleString()} <span className="text-xs text-gray-500">USD</span>
                                    </p>
                                </CardContent>

                                <CardFooter className="p-4 pt-0">
                                    <Button asChild className="w-full">
                                        <Link href={`/${tenant}/product/${product.slug}`}>
                                            View Details
                                        </Link>
                                    </Button>
                                </CardFooter>
                            </Card>
                        )
                    })
                )}
            </div>
        </div>
    );
}
